%% ============================================================
%  ALGORITMO GENÉTICO 
%  Ex1:
%  Autor: Eduardo, Rodrigo e João
% ============================================================
%Ex1:
%Programa de optimizacao
%X = GA(FITNESSFCN,NVARS,A,b,Aeq,beq,lb,ub,NONLCON,options)
options = optimoptions('ga','PlotFcns',...
 {@gaplotbestf,@gaplotbestindiv,@gaplotexpectation,@gaplotstopping},...
 'PopInitRange',[0;2*pi]);
[x fval] = ga(@senoMin,1,[],[],[],[],0,2*pi,[],options)